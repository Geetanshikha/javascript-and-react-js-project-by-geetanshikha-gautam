import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        This was an amazing bootcamp encoraged me to learn more and more about
        javascript and reactand basic web designing stuff like html an css a
        huge thanks to shaurya sir and team...
      </p>
    </div>
  );
}

export default Note;
